 import firebase from "firebase";

//initialize your database
const firebaseConfig = {
  apiKey: "AIzaSyCY-lipcqYIjC717RWuNGPEOCzaSmFaLlo",
  authDomain: "c-60-377b7.firebaseapp.com",
  databaseURL: "https://c-60-377b7-default-rtdb.firebaseio.com",
  projectId: "c-60-377b7",
  storageBucket: "c-60-377b7.appspot.com",
  messagingSenderId: "373259887976",
  appId: "1:373259887976:web:c77758700250ab9f4962dd"
};
if(!firebase.apps.length){
   firebase.initializeApp(firebaseConfig);
}
  export default firebase.database()
 

  